/*
* author - mandeep singh
* 13-04-2017
* copyright 2017 reserved
    GNU GENERAL PUBLIC LICENSE
    Version 3, 29 June 2007


*/

#include "declaration.h"

//extern functions
extern void select_particular_query(string table_name,string col_to_search,string col_value,std::map<string,int> &display_col_list);
