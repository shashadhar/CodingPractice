/*
    * mandeep singh all rights reserved
    * header file for parser.c
*/

#include "declaration.h"

extern void get_query();
